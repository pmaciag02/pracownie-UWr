package pl.drugi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DrugiApplication {

	public static void main(String[] args) {
		SpringApplication.run(DrugiApplication.class, args);
	}

}
