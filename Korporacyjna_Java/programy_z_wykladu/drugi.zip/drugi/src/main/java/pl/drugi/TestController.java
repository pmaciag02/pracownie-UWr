package pl.drugi;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.List;

@RestController
public class TestController {

    @Autowired
    private StringWrapperRepository repository;

    @GetMapping("/version")
    public String getVersion() {
        System.out.println("Click");
        repository.save(new StringWrapper("Version checked: " + new Date()));
        return "0.0.3";
    }

    @GetMapping("/all")
    public List<StringWrapper> getAll() {
        return repository.findAll();
    }
}
