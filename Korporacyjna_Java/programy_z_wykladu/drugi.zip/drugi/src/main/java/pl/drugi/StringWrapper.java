package pl.drugi;

import jakarta.persistence.*;

import java.util.Objects;

@Entity
@Table
public class StringWrapper {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column
    private String stringValue;

    public StringWrapper() {
    }

    public StringWrapper(String stringValue) {
        this.stringValue = stringValue;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getStringValue() {
        return stringValue;
    }

    public void setStringValue(String stringValue) {
        this.stringValue = stringValue;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof StringWrapper)) return false;
        StringWrapper that = (StringWrapper) o;
        return id.equals(that.id) && Objects.equals(stringValue, that.stringValue);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, stringValue);
    }
}
