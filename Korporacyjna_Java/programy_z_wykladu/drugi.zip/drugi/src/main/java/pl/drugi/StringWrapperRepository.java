package pl.drugi;

import org.springframework.data.jpa.repository.JpaRepository;

public interface StringWrapperRepository extends JpaRepository<StringWrapper, Long> {
}
