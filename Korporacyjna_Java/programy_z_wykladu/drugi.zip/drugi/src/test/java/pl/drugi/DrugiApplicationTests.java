package pl.drugi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DrugiApplicationTests {

	@Test
	void contextLoads() {
	}

}
