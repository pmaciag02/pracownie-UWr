#include <stdio.h>

int main(void) {
  puts("first time");
  puts("second time");
  return 0;
}
